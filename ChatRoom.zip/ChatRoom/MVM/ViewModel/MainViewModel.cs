﻿using ChatRoom.MVM.Core;
using ChatRoom.MVM.Model;
using ChatRoom.Net;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ChatRoom.MVM.ViewModel
{
    class MainViewModel
    {
        public ObservableCollection<UserModel> Users { get; set; }
        public ObservableCollection<string> Messages { get; set; }
        public RelayCommand ConnectToServerCommand { get; set; }
        public RelayCommand SendMsgCommand { get; set; }
        public string Username { get; set; }
        public string Msg { get; set; }

        private Server _server;
        public MainViewModel() 
        {
            Users = new ObservableCollection<UserModel>();
            Messages = new ObservableCollection<string>();
            _server = new Server();
            _server.connectedEvent += UserConnected;
            _server.msgReceivedEvent += MsgReceived;
            _server.disconnectedEvent += UserDisconnected;

            ConnectToServerCommand = new RelayCommand(o => _server.ConnectToServer(Username), o => !string.IsNullOrEmpty(Username));
            SendMsgCommand = new RelayCommand(o => _server.SendMsgToServer(Msg), o => !string.IsNullOrEmpty(Msg));
        }

        private void MsgReceived()
        {
            var msg = _server.PacketReader.ReadMsg();
            Application.Current.Dispatcher.Invoke(() => Messages.Add(msg));
        }

        private void UserDisconnected()
        {
            var uid = _server.PacketReader.ReadMsg();
            var user = Users.Where(x => x.UID == uid).FirstOrDefault();
            Application.Current.Dispatcher.Invoke(() => Users.Remove(user));
        }
        private void UserConnected()
        {
            var user = new UserModel
            {
                Username = _server.PacketReader.ReadMsg(),
                UID = _server.PacketReader.ReadMsg(),
            };

            if(!Users.Any(x => x.UID == user.UID))
            {
                Application.Current.Dispatcher.Invoke(() => Users.Add(user));
            }
        }
    }
}
