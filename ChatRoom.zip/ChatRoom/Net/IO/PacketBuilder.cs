﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatRoom.Net.IO
{
    class PacketBuilder
    {
        MemoryStream _ms;
        public PacketBuilder()
        {
            _ms = new MemoryStream();
        }

        public void WriteOpCode(byte opcode)
        {
            _ms.WriteByte(opcode);
        }

        public void WriteMsg(string str)
        {
            var strLength = str.Length;
            _ms.Write(BitConverter.GetBytes(strLength));
            _ms.Write(Encoding.ASCII.GetBytes(str));
        }

        public byte[] GetPacketBytes()
        {
            return _ms.ToArray();
        }
    }
}
